<?php
session_start();
unset($_SESSION['login_user']);
header("Location: index.html");
//if(session_destroy()) // Destroying All Sessions
//{
//header("Location: index.html"); // Redirecting To Home Page
//}
?>