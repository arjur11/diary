<?php
 
require 'lib.php';
 
$object = new CRUD();
 
// Design initial table header
$data = '<table class="table table-bordered table-striped">
                        <tr>
                            <th>No.</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th> Relation_type</th>
							<th>Address</th>
							<th>Phone1_type</th>
							<th>Phone1_no<th>
							<th>Phone2_type</th>
							<th>Phone2_no<th>
                            <th>Update</th>
                            <th>Delete</th>
                        </tr>';
 
 
$users = $object->Read();
 
if (count($users) > 0) {
    $number = 1;
    foreach ($users as $user) {
        $data .= '<tr>
                <td>' . $number . '</td>
                <td>' . $user['Name'] . '</td>
                <td>' . $user['email'] . '</td>
                <td>' . $user['address'] . '</td>
				<td>' . $user['relation_type'] . '</td>
                <td>' . $user['phone1_type'] . '</td>
                <td>' . $user['phone1_no'] . '</td>
				<td>' . $user['phone2_type'] . '</td>
				<td>' . $user['phone2_no'] . '</td>
                <td>
                    <button onclick="GetUserDetails(' . $user['id'] . ')" class="btn btn-warning">Update</button>
                </td>
                <td>
                    <button onclick="DeleteUser(' . $user['id'] . ')" class="btn btn-danger">Delete</button>
                </td>
            </tr>';
        $number++;
    }
} else {
    // records not found
    $data .= '<tr><td colspan="6">Records not found!</td></tr>';
}
 
$data .= '</table>';
 
echo $data;
 
?>