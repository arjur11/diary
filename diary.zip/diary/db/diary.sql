-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 04, 2017 at 10:57 AM
-- Server version: 5.6.16
-- PHP Version: 5.5.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `diary`
--

-- --------------------------------------------------------

--
-- Table structure for table `addcontact`
--

CREATE TABLE IF NOT EXISTS `addcontact` (
  `id` bigint(6) unsigned NOT NULL AUTO_INCREMENT,
  `Name` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `relation_type` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `phone1_type` varchar(20) NOT NULL,
  `phone1_no` varchar(20) NOT NULL,
  `phone2_type` varchar(20) NOT NULL,
  `phone2_no` int(20) NOT NULL,
  `user` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user` (`user`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `addcontact`
--

INSERT INTO `addcontact` (`id`, `Name`, `email`, `relation_type`, `address`, `phone1_type`, `phone1_no`, `phone2_type`, `phone2_no`, `user`) VALUES
(1, 'Saiful Islam', 'arjur.uits@yahoo.com', 'Brother', 'fdsfsdf', 'Cell phone', '01723394564', 'Cell phone', 1674140156, 6),
(2, 'shykat', 'shykat789@gmail.com', 'other', 'shymali,pccultural ,', 'Cell phone', '01723394564', 'Cell phone', 1674140156, 6),
(3, 'Saiful Islam', 'saiful@gmail.com', 'Friend', 'hajiganj,chandpur,', 'Cell phone', '01729714006', 'Cell phone', 1674147412, 7),
(4, 'Masud', 'masud@gmail.com', 'Friend', 'Mollahdohor,hajigjanj,chandpur', 'Cell phone', '01922663639', 'Cell phone', 1772210770, 8),
(5, 'Rakibul hasan', 'rockyhasan82@gmail.com', 'other', 'horipur,Thakurgaw.', 'Cell phone', '01792782996', 'Land phone', 0, 8),
(6, 'fayez', 'fayez@gmail.com', 'Friend', 'chandina,comilla.', 'Cell phone', '019176244468', 'Cell phone', 0, 8),
(7, 'fosial', 'foisal@yahoo.com', 'Friend', 'hajiganj,chandpur.', 'Cell phone', '018257562714', 'Land phone', 0, 8),
(8, 'falash kaka', 'palash14@gmail.com', 'Brother', 'gopalganj.', 'Cell phone', '01671454109', 'Land phone', 0, 8),
(9, 'fokrul bai', '', 'other', 'hajiganj,chandpur', 'Land phone', '01727893512', 'Land phone', 0, 8),
(10, 'Anait', '', 'Relative', 'tongi,gazipur,dhaka', 'Land phone', '01751588474', 'Land phone', 0, 8),
(11, 'arif ', '', 'Friend', 'Dhaka.', 'Cell phone', '01677090104', 'Land phone', 0, 9),
(12, 'Baher', 'Baher@gmail.com', 'Brother', 'Palishara,Hajiganj,Chandpur', 'Cell phone', '01778428630', 'Cell phone', 17323762, 6);

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE IF NOT EXISTS `signup` (
  `id` bigint(6) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  `user_id` varchar(20) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone_type` varchar(8) NOT NULL,
  `phone_no` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`id`, `name`, `user_id`, `email`, `phone_type`, `phone_no`, `password`) VALUES
(6, 'masud', 'masud11', 'masud@gmail.com', 'Cell pho', '019241062541', '123456'),
(7, 'joshim', 'joshim1', 'joshim@gmail.com', 'Cell pho', '0147564136', '789456'),
(8, 'Arjur Rahman', 'arjur123', 'arjur.uits11@gmail.com', 'Cell pho', '01723391854', '111222'),
(9, 'faysal', 'faysal11', 'quazifaysal01@gmail.com', 'Cell pho', '01825762714', 'faysal');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` bigint(6) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(30) NOT NULL,
  `password` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `email`, `password`) VALUES
(1, 'arjur.uits11@gmail.com', '123456');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `addcontact`
--
ALTER TABLE `addcontact`
  ADD CONSTRAINT `addcontact_ibfk_1` FOREIGN KEY (`user`) REFERENCES `signup` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
