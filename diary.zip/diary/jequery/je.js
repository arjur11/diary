
$(document).ready(function(){
    $("h1").hide(20000);
       
        
    });
