<?php

include'include/head.php';
?>

<form id="myform"  action="" method="post">
<div class="container">    
  <div class="row content">
   
    
    <div class="col-sm-12 text-center"> 
          
      <h3>Create Account </h3>
      
       <!-- <p>Lorem ipsum...</p>-->
    </div>
        <!--<div class="container">-->
             <div class="col-sm-2">
                <div class="row"></div>
                </div>
   
   
        <div class="col-sm-8" style="background-color:">   
              <div class="row">
                    <div class="panel panel-default">
                        <div class="panel-body">
                     <div class="col-sm-6">
                    <div class="form-group">
                       <label for="usr">Name:</label>
                    <input type="text" name="name" class="form-control" id="usr" 
                 placeholder="Full Name" required>
                </div>

                   <div class="form-group">
               <label for="userid">User ID:</label>
                                   <input type="text"  name="user_id" class="form-control" id="userid"
                                            placeholder="UserId"  required>
                   </div>
            <div class="form-group">
               
               <label for="inputDoB">Phone Number type:</label>
                <select class="form-control" name="phone_type">                             
                <option>Land phone</option>
                <option>Cell phone</option>
                </select>
            </div>
             <div class="from-group">
               <input type="text" name="phone_no" class ="form-control" id="InputDoB"
                      placeholder="Phone Number">
            </div>                     
                      
                        </div> 
                        
           <div class="col-sm-6">
               <div class="form-group">
           <label for="email">Email Adress:</label>
           
             <input type="email" name="email" class="form-control" id="email"
         placeholder= "email">
               </div>
               
        <div class="form-group">
           <label for="pass1" class="control-label">Password</label>
           <input name="pass1"  class="form-control" id="pass1" data-minlength="6" type="password"
               placeholder="Password" onfocusin="OnFocusInmyForm(event)" required>
                 
               </div>
               

                <div class="form-group">
               <label for= "pass2">Confirm Password:</label>
               <input name="pass2" class="form-control" id="pass2" onkeyup="checkPass(); return false;" 
                  type="password" placeholder="Confirm Password" onfocusout="OnFocusOutmyform(event)" required> 
               <span id="confirmMessage" class="confirmMessage"></span>
                </div>
          
                    
              
               <br><br>
                        <div class="form-group col-centered">
                        <input type="reset" class="btn btn-parimary"></input>
                        <button type="submit" value="submit" name="submit"  class="btn btn-primary">Register</button>                    
                         </div>
             
                     </div>
                                
        <!--<div class="col-sm-6" style="text-align: center"> -->
                
                        
                
                        </div>
         </div>
      
        </div>
     </div>
        <div class="col-sm-2 sidenav">
        <!--
             <div class="well">
             <p>ADS</p>

             </div>
             <div class="well">
               <p>ADS</p>
            </div>-->
         </div>

    </div>


</div>
</form>
<?php
if(isset($_POST["submit"])){
$hostname='localhost';
$username='root';
$password='';

try {
    $dbh = new PDO("mysql:host=$hostname;dbname=diary",$username,$password);

    $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); // <== add this line

 
$sql = "INSERT INTO signup (name, email,user_id,phone_type,phone_no,password )
VALUES ('".$_POST["name"]."','".$_POST["email"]."','".$_POST["user_id"]."','".$_POST["phone_type"]."','".$_POST["phone_no"]."','".$_POST["pass2"]."')";

    if ($dbh->query($sql))
        {
         echo "<script type= 'text/javascript'>alert('Sign up Successfully');</script>";
        } 
    else{
         echo "<script type= 'text/javascript'>alert('Data not successfully Inserted.');</script>";
        }

    $dbh = null;
    }
catch(PDOException $e)
    {
    echo $e->getMessage();
    }

}
?>
       <script>

  function checkPass()
{
    //Store the password field objects into variables ...
    var pass1 = document.getElementById('pass1');
    var pass2 = document.getElementById('pass2');
    //Store the Confimation Message Object ...
    var message = document.getElementById('confirmMessage');
    //Set the colors we will be using ...
    var goodColor = "#66cc66";
    var badColor = "#ff6666";
    //Compare the values in the password field 
    //and the confirmation field
    if(pass1.value == pass2.value){
        //The passwords match. 
        //Set the color to the good color and inform
        //the user that they have entered the correct password 
        pass2.style.backgroundColor = goodColor;
        message.style.color = goodColor;
        message.innerHTML = "Passwords Match!"
    }else{
        //The passwords do not match.
        //Set the color to the bad color and
        //notify the user.
        pass2.style.backgroundColor = badColor;
        message.style.color = badColor;
        message.innerHTML = "Passwords Do Not Match!"
    }
}  
 </script> 


 
 
        <?php
        include('include/footer.php');
        ?>
