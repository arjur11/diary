<?php
session_start();
include 'include/head.php';
?>

<?php
$servername = "localhost";
$username = "root";
$password = "";

// Create connection
$conn = new mysqli($servername, $username, $password);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully";
?>
<?php
$cid = $_GET['cid'];
echo $cid; 
$query = "select * from addcontact where id=$cid";

echo $query;
//die;


?>
<form action="" method="post">
        <div class="container">    
            <div class="row content">
                <div class="col-sm-12 text-center"> 
                <h2>EDIT  CONTACTS INFORMATION</h2>
                    </div>
        <!--<div class="container">-->
                        <div class="col-sm-4">
                           <div class="row"></div>
                            </div>
        <div class="col-sm-4" style="background-color:	#F5F5F5 ;">   
            <div class="row" >
                <div class="panel-body">
                     <!--<div class="col-sm-8>-->
                    <div class="input-group">
                        <div class="form-group">
                       
                        <input type="text" name="phone1_type" class="form-control" id="usr" 
                         placeholder="Phone Type" value="<?=$row['phone1_type']?>">
                   
				
                        <input type="text" name="phone1_no" class="form-control" id="usr" 
                         placeholder="Phone NO" value="<?=$row['phone1_no']?>">
                        <input type="text" name="name" class="form-control" id="usr" 
                         placeholder="Phone Type" value="<?=$row['phone2_no']?>">
						
                        <input type="text" name="Phone2 No" class="form-control" id="usr" 
                               placeholder="Phone 2" value="<?=$row['phone2_no']?>">
                      

                        <input id="email" type="text" class="form-control"
                          name="email" placeholder="Email">
                            
                                
                        <br>
													     
                        <textarea name="address" rows="5" cols="30" placeholder="Adress"></textarea>
                        <button type="submit"  name="submit" value="submit" class="btn btn-success">Save</button>

			</div>
			</div>
                
                
		</div>
		</div>
            </div>
	</div>
      
   
                        <div class="col-sm-4 sidenav">
                        <!--
                             <div class="well">
                             <p>ADS</p>

                             </div>
                             <div class="well">
                               <p>ADS</p>
                            </div>-->
                         </div>
            
        </div>
        </div>
		
</form>
  
   <?php
include('include/footer.php');
?>