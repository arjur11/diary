<!DOCTYPE html>
<html lang="en">
<head>
  <title>Diary</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
     <link rel="stylesheet" type= "text/css" href="style.css"></link>
        <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
    <script src="jequery/jquery-1.11.3.min.js"></script>
   <script src="bootstrap/js/bootstrap.min.js"></script> 
    
   <script>

</script>
</head>
<body style="background-color:#a0a9aa">

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#">Diary</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
      <li>   <a href="index.html" class="btn btn-default btn-sm">
          <span class="glyphicon glyphicon-home"></span> Home
        </a></li>
        <li><a href="about.php">About</a></li>
		<?php if(isset($_SESSION['login_user']))
		{
		?>
            <li><a href="addcontact.php">Addcontact</a></li>
         <li><a href="allcontactlist.php">My Contact List</a></li>
		
      </ul>
	  <?php
	  }
	  ?>
    <ul class="nav navbar-nav navbar-right">
         <li><a href="user.php"><span class="glyphicon glyphicon-log-in"></span> Signup</a></li>
		  <li><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> login</a></li>
		 
         <li><a href="logout.php"><span class="glyphicon glyphicon-log-in"></span> logout</a></li>
      </ul>
        <ul class="nav navbar-nav navbar-right">
       
        </ul> 
    </div>
  </div>
</nav>