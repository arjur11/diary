  <?php
    $host = 'localhost';
    $dbname = 'diary';
    $username = 'root';
    $password = '';
 
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
	//find how many data table
 
    $sql = 'SELECT id,
                    name,
                    email,
                    relation_type,
                    address,
                    phone1_type,
                    phone1_no,
                    phone2_type,
                    phone2_no
               FROM addcontact
               where user='.$_SESSION['userid'].
              ' ORDER BY id';
    echo $sql;
    $q = $pdo->query($sql);
    $q->setFetchMode(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Could not connect to the database $dbname :" . $e->getMessage());
}
?>