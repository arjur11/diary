 <footer class="footer text-center">
  <p>&copy; Arjur Rahman, <?= date('Y') ?></p>
</footer>
 
</body>
</html>