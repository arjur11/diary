<?php
include 'include/head.php';
?>

  
     <form action="" method="post">
        <div class="container-fluid">    
            <div class="row content">
                <div class="col-sm-12 text-center"> 
                <h2> Will be add...</h2>
                    </div>
        <!--<div class="container">-->
                        <div class="col-sm-2">
                            <div class="row">
                                                    
                            </div>
                            </div>
                <div class="col-sm-8">   
                
					<div id="profile">
						
						
						</div>
    
                 </div>
      
   
                        <div class="col-sm-2 sidenav">
                        <!--
                             <div class="well">
                             <p>ADS</p>

                             </div>
                             <div class="well">
                               <p>ADS</p>
                            </div>-->
                         </div>
            </div>
        </div>

     </form>
   <?php
include('include/footer.php');
?>
 
