<?php
session_start();
include 'include/head.php';
    ?>
 <form id="myform"  action="" method="post">
        <div class="container">    
           <div class="row content">
   
    
            <div class="col-sm-12 text-center"> 

              <h3>Add contact Address </h3>

               <!-- <p>Lorem ipsum...</p>-->
            </div>
        <!--<div class="container">-->
                <div class="col-sm-2">
                   <div class="row"></div>
                   </div>
            
    <div class="col-sm-8" style="background-color:">   
        <div class="row">
            <div class="panel panel-default">
                <div class="panel-body">
                    <div class="col-sm-6">
                        <div class="form-group">
                        <label for="usr">Name:</label>
                        <input type="text" name="name" class="form-control" id="usr" 
                         placeholder="Full Name" required>
                        </div>

                        <div class="form-group">
                         <label for="inputDoB">Relation type:</label>
                         <select class="form-control" name="relation_type">                             
                             <option>Friend</option>
                             <option>Brother</option>
                             <option>Cousin</option>
                             <option>Sister</option>
                             <option>Relative</option>
                             <option>other</option>
                         </select>
                        </div>
                         
                        <div class="form-group">
                            <label for="address">Address:</label>
                            <textarea name="address" rows="6" cols="30"></textarea>
                        </div>

                    </div>
                    <div class="col-sm-6">
                        <div class="form-group">
                        <label for="email">Email Adress:</label>
                         <input type="email" name="email" class="form-control" id="email"
                        placeholder= "email">
                        </div>
                        <div class="form-group">
                            <label for="inputDoB">Phone Number type:</label>
                            <select class="form-control" name="phone1_type">                             
                            <option>Land phone</option>
                            <option>Cell phone</option>
                            </select>
                        </div>
       <!--  <label for="phoneno">Phone Number:</label>-->
                        <div class="form-group">
                        <input type="text" name ="phone1_no"class ="form-control" id="inputDoB"
                               placeholder="Phone Number">
                        <label for="inputDoB">Phone Number type:</label>
                        <select class="form-control" name="phone2_type">                             
                            <option>Land phone</option>
                            <option>Cell phone</option>
                            </select>
                        </div>

                        <div class="from-group">
                            <input type="text" name ="phone2_no" class ="form-control" id="InputDoB"
                              placeholder="Phone Number">
                        </div>
                            <br>
                        <div class="form-group col-centered">
                            <input type="reset" name="reset" class="btn btn-parimary"></input>
                             <button type="submit" value="submit" name="submit"  class="btn btn-primary">Save</button>               
                        </div>
       
       
       
                    </div>
                                
        <!--<div class="col-sm-6" style="text-align: center"> -->
                
                        
                

                </div>
            </div>
         </div>
    </div>
       
        <!--  <div class="col-sm-2">
 <!--
      <div class="well">
      <p>ADS</p>
     
      </div>
      <div class="well">
        <p>ADS</p>
     </div>-->
  

   
       
       
    
    
      


<!--
      <h1>Welcome </h1>
     <p>Arjur Rahman</p>

      <hr>
        
      <h3> arjur rahman</h3>
      <p>Lorem ipsum...</p>
    </div>
-->
                    <div class="col-sm-2 sidenav">
                                                            <!--
                                                                 <div class="well">
                                                                 <p>ADS</p>

                                                                 </div>
                                                                 <div class="well">
                                                                   <p>ADS</p>
                                                                </div>-->
                    </div>


  <!--</div> -->
        </div>
    </div>
 </form>
<?php
if(isset($_POST["submit"])){
$hostname='localhost';
$username='root';
$password='';

try {
    $dbh = new PDO("mysql:host=$hostname;dbname=diary",$username,$password);

    $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); // <== add this line

 
$sql = "INSERT INTO addcontact (name, email,relation_type,address,phone1_type,phone1_no,phone2_type,phone2_no )
VALUES ('".$_POST["name"]."','".$_POST["email"]."','".$_POST["relation_type"]."','".$_POST["address"]."','".$_POST["phone1_type"]."','".$_POST["phone1_no"]."','".$_POST["phone2_type"]."','".$_POST["phone2_no"]."')";

if ($dbh->query($sql))
    {
        echo "<script type= 'text/javascript'>alert('Add Contact Successfully');</script>";
    } 
else
    {
        echo "<script type= 'text/javascript'>alert('Data not successfully Inserted.');</script>";
    }

        $dbh = null;
    }
catch(PDOException $e)
    {
        echo $e->getMessage();
    }

}
?>



                        <script>
                     var x = document.getElementById("myForm");
                     x.addEventListener("focusin", myFocusFunction);
                     x.addEventListener("focusout", myBlurFunction);

                     function myFocusFunction() {
                         document.getElementById("usr").style.backgroundColor = "yellow";  
                     }

                     function myBlurFunction() {
                         document.getElementById("usr").style.backgroundColor = "";  
                     }
                     </script>


              <?php
             include('include/footer.php');
             ?>
