<?php
        
// Create connection
$conect =  mysqli_connect("localhost", "root", "", "dairy");

$sql= "SELECT * FROM addcontact ORDER BY id DESC";
$output='';
$result=  mysqli_query($conect, $sql);

$output.= '
        <div class="table-respnosive">
		<table class="table table-bordered">
            <tr>
               <th>Id</th>
                       <th width="10%">Name</th>
                       <th width="40%">Email</th>
                       <th width="40%">Relation_Type</th>
                       <th width="40%">Address</th>
                       <th width="40%">Phone_Type</th>
                       <th width="40%">Phone_Type</th> 
                       <th width="10%">delet</th>
            </tr>';
if(mysqli_num_rows($result) > 0)
 {
     // output data of each row
     while ($row = mysqli_fetch_array($result)) {
         $output .='<td>'.$row["id"].'</td>
                 <td class="Name" data-id1="'.$row["id"].'"contenteditabl>'.$row["Name"].' </td>
                 <td class="email" data-id2="'.$row["id"].'"contenteditabl>'.$row["email"].' </td>
                 <td class="relation_type" data-id3="'.$row["id"].'"contenteditabl>'.$row["relation_type"].' </td>
                 <td class="address" data-id4="'.$row["id"].'"contenteditabl>'.$row["address"].' </td>
                 <td class="phone1_type" data-id5="'.$row["id"].'"contenteditabl>'.$row["phone1_type"].' </td>
                 <td class="phone1_no" data-id6="'.$row["id"].'"contenteditabl>'.$row["phone1_no"].' </td>
                 <td class="phone2_no" data-id7="'.$row["id"].'"contenteditabl>'.$row["phone2_no"].' </td>
                 <td class="phone2_no" data-id8="'.$row["id"].'"contenteditabl>'.$row["phone2_no"].' </td>
                 <td><button name="btn-delete" id ="btn-delete" data-id9="'.$row["id"].'">delete</td>
                     ';
                 
     }
     $output.='<tr>
             <td></td>
                    <td id="Name" contenteditable></td>
                    <td id="email" contenteditable></td>
                    <td id="realtion_type" contenteditable></td>
                    <td id="address" contenteditable></td>
                    <td id="phone1_type" contenteditable></td>
                    <td id="phone1_no" contenteditable></td>
                    <td id="phone2_type" contenteditable></td>
                    <td id="phone2_no" contenteditable></td>
                    <td id="button name="btn_add" id="btn_add" class="btn btn-xs
                        btn-success">+</button></td>
                        
               </tr>';
} 
else {
  $output.='<tr>
                <td colspan="4">data not Found</td>
                    </tr>';
                    
}
$output.='</table>
    </div>';

?>