<?php
session_start();
include 'include/head.php';
?>
<?php
include 'include/datafetch.php';
?>
     <form action=" " method="post">
        <div class="container-fluid">    
            <div class="row content">
                <div class="col-sm-12 text-center"> 
                <h2> All Contact List...</h2>
                    </div>
                       
                <div class="col-sm-12">
                  <div class="table-responsive">     
                       <table  id= data_live class="table table-bordered">
                                        <thead>
                                                <tr>
                                                        <th width="10%">ID</th>
                                                         <th width="10%">Name</th>
                                           <th width="30%">Email</th>
                                           <th width="20%">Relation_Type</th>
                                           <th width="400%">Address</th>
                                           <th width="30%">Phone_Type</th>
                                           <th width="30%">Phone_No</th> 
                                           <th width="30%">Phone_Type</th>
                                           <th width="30%">Phone_No</th> 
                                           <th width="5%">Edit</th>
                                                <th width="5%">Delete</th>
                                                </tr>
                                        </thead>
                                        <tbody>
                                                <?php while ($row = $q->fetch()): ?>
                                                        <tr>
                                                                <td><?php echo htmlspecialchars($row['id']) ?></td>
                                                                <td><?php echo htmlspecialchars($row['name']); ?></td>
                                                                <td><?php echo htmlspecialchars($row['email']); ?></td>
                                                                <td><?php echo htmlspecialchars($row['relation_type']); ?></td>
                                                                <td><?php echo htmlspecialchars($row['address']); ?></td>
                                                                <td><?php echo htmlspecialchars($row['phone1_type']); ?></td>
                                                                <td><?php echo htmlspecialchars($row['phone1_no']); ?></td>
                                                                <td><?php echo htmlspecialchars($row['phone2_type']); ?></td>
                                                                <td><?php echo htmlspecialchars($row['phone2_no']); ?></td>
                                                                 <td><a class="button" href="editinfo.php?cid=<?= $row['id']?>">Edit</td>
                                                                 <td><a class="button" href="delete1.php.php?cid=<?= $row['id']?>">Delete</td>

                                                                </tr>
                                                        <?php endwhile;?>
                                        </tbody>
                                </table>
                                        </div>
                </div>
				</div>
			</div>
		</div>
</form>
   <?php
include('include/footer.php');
?>
 

      

<script type="text/javascript">
    $(document).ready(function(){
       function fetch_data(){
		$.ajax({
		url:"select.php",
		method:"POST",
		success:fucntion(data){
		$('data_live').html(data);
		}
		
		});
	   
	   }
       fetch_data();
	   
           function edit_data(id,text,column_name)
           {
               $.ajax({
                   url:"edit.php",
                   data:{id:id, text:text, column_name:column_name}
                   dataType:"text",
                   success:fucntion(data){
                       alert(data);
                   }   
               });
           }
           $(document).on('blur','.name',function()
           {
               var id =$(this).data("id1");
               var text=$(this).text();
               edit_data(id,Name,"Name")
           });
           $(document).on('blur','.email',function()
           {
               var id =$(this).data("id2");
               var text=$(this).text();
               edit_data(id,email,"email")
           });
           $(document).on('blur','.relation_type',function()
           {
               var id =$(this).data("id3");
               var text=$(this).text();
               edit_data(id,relation_type,"relation_type")
           });
           $(document).on('blur','.address',function()
           {
               var id =$(this).data("id4");
               var text=$(this).text();
               edit_data(id,address,"address")
           });
           $(document).on('blur','.phone1_type',function()
           {
               var id =$(this).data("id5");
               var text=$(this).text();
               edit_data(id,phone1_type,"phone1_type")
           });
           $(document).on('blur','.phone1_no',function()
           {
               var id =$(this).data("id6");
               var text=$(this).text();
               edit_data(id,phone1_no,phone1_no")
           });
           $(document).on('blur','.phone2_type',function()
           {
               var id =$(this).data("id7");
               var text=$(this).text();
               edit_data(id,phone2_type,"phone2_type")
           });
           $(document).on('blur','.phone2_no',function()
           {
               var id =$(this).data("id8");
               var text=$(this).text();
               edit_data(id,phone2_no,"phone2_no")
           });
           $(document).on('click', '.btn_delete',function(){
               
               var id=$(this).data("id3");
               if("Are  you sure you want to  data  delete confirme this?"))
               {
                    $.ajax({

                       url: "delete.php",
                       method: "post",
                       data: {id:id},
                       dataType:"text",
                       success:fucntion(){

                           alert(data);
                           fetch_data();
                       }
                    });
                }
           });
       
       
      

    });
</script>