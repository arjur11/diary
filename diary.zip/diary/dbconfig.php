<?php
    $host = 'localhost';
    $dbname = 'dairy';
    $username = 'root';
    $password = '';