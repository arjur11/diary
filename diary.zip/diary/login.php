<?php
include'include/head.php';
if(isset($_SESSION['login_user'])){
header("location: head.php");
}
?>


<?php
session_start(); // Starting Session
$error=''; // Variable To Store Error Message
if (isset($_POST['submit'])) {
if (empty($_POST['email']) || empty($_POST['password']))
	{
$error = "Email or Password is invalid";
	}
else
{
// Define $email and $password
$email=$_POST['email'];
$password=$_POST['password'];
// Establishing Connection with Server by passing server_name, user_id and password as a parameter
$connection = mysql_connect("localhost", "root", "");
// To protect MySQL injection for Security purpose
$email = stripslashes($email);
$password = stripslashes($password);
$email = mysql_real_escape_string($email);
$password = mysql_real_escape_string($password);
// Selecting Database
$db = mysql_select_db("diary", $connection);
// SQL query to fetch information of registerd users and finds user match.
$query = mysql_query("select * from signup where password='$password' AND email='$email'", $connection);
$rows = mysql_num_rows($query);
$data = mysql_fetch_array($query);
if ($rows == 1) {
$_SESSION['login_user']=$email; // Initializing Session
$_SESSION['userid']=$data['id'];
header("location:addcontact.php"); // Redirecting To Other Page
} 
else
 {
$error = "email or Password is invalid";
}
mysql_close($connection); // Closing Connection
}
}
?>
  
<form action="" method="post">
        <div class="container">    
            <div class="row content">
                <div class="col-sm-12 text-center"> 
                <h2>Sign In</h2>
                    </div>
        <!--<div class="container">-->
                        <div class="col-sm-4">
                           <div class="row"></div>
                            </div>
        <div class="col-sm-4" style="background-color:	#F5F5F5 ;">   
            <div class="row" >
                <div class="panel-body">
                     <!--<div class="col-sm-8>-->
                                <div class="input-group">
                                    <span class="input-group-addon">
                                    <i class="glyphicon glyphicon-user"></i>
                                    </span>
                                    <input id="email" type="text" class="form-control"
                                      name="email" placeholder="Email">
                                </div>
                                <div class="input-group">
                                    <span class="input-group-addon">
                                    <i class="glyphicon glyphicon-lock"></i>
                                    </span>
                                    <input id="password" type="password" class="form-control"
                                    name="password" placeholder="********">
                                    <span><?php echo $error; ?></span>
                                </div>
                                                    <br>
                                <div class="col-sm-6 form-group">
                                          <label><input id="rememberme" name="rememberme" value="remember" type="checkbox" />
                                                    &nbsp;Remember me</label>
                                </div>
                                <div class="form-group">

                                <button type="submit"  name="submit" value="submit" class="btn btn-success">login</button>

                                </div>
                </div>
                

            </div>
         </div>
      
   
                        <div class="col-sm-4 sidenav">
                        <!--
                             <div class="well">
                             <p>ADS</p>

                             </div>
                             <div class="well">
                               <p>ADS</p>
                            </div>-->
                         </div>
            
        </div>
        </div>
		<?php echo $error; ?>
</form>

   <?php
	include('include/footer.php');
    ?>
 
 
