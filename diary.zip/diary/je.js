<script>
$(document).ready(function(){
    $div(".h1").hide(2000);
       
        
    });

</script>