<?php
session_start();
include 'include/head.php';
?>

<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.9/css/jquery.dataTables.min.css"/>
	 
<script type="text/javascript" src="https://cdn.datatables.net/1.10.9/js/jquery.dataTables.min.js"></script>

     <form action="" method="post">
        <div class="container-fluid">    
            <div class="row content">
                <div class="col-sm-12 text-center"> 
                <h2> Will be add...</h2>
                    </div>
       
                        <div class="col-sm-0">
                            <div class="row">
                             
                            </div>
                            </div>
                <div class="col-sm-12">   
                
				<div class="row">
                 <div class="table-responsive">     
                       <table id="table_data" class="table table-bordered">
                            
						<thead>
							<tr>
								<th width="10%">ID</th>
								 <th width="10%">Name</th>
						   <th width="30%">Email</th>
						   <th width="20%">Relation_Type</th>
						   <th width="400%" "contenteditable">Address</th>
						   <th width="30%">Phone_Type</th>
						   <th width="30%">Phone_No</th> 
						   <th width="30%">Phone_Type</th>
						   <th width="30%">Phone_No</th> 
						   <th width="5%">Edit</th>
							<th width="5%">Delete</th>
							</tr>
						</thead>
						</table>
                <tbody>    	
				
				</div>
    
                 </div>
				 </div>
      
   
                        <div class="col-sm-0 sidenav">
                        <!--
                             <div class="well">
                             <p>ADS</p>

                             </div>
                             <div class="well">
                               <p>ADS</p>
                            </div>-->
                         </div>
            </div>
        </div>

     </form>
   <?php
include('include/footer.php');
?>
 
<script type="text/javascript">
$( document ).ready(function() {
$('#table_data').DataTable({
				 "bProcessing": true,
         "serverSide": true,
         "ajax":{
            url :"response.php", // json datasource
            type: "post",  // type of method  ,GET/POST/DELETE
            error: function(){
              $("table_data").css("display","none");
            }
          }
        });

});
</script>
